export const SET_POSTS = 'SET_POSTS';
export const REMOVE_POST = 'REMOVE_POST';
export const SET_PAGE = 'SET_PAGE';

export const setPosts = (posts) => ({
  type: SET_POSTS,
  payload: posts,
});

export const removePost = (postId) => ({
  type: REMOVE_POST,
  payload: postId,
});

export const setPage = (page) => ({
  type: SET_PAGE,
  payload: page,
});
