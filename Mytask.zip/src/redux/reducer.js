import { combineReducers } from 'redux';
import { SET_POSTS, REMOVE_POST, SET_PAGE } from './actions';

const initialState = {
  posts: [],
  currentPage: 1,
};

const postReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_POSTS:
      return { ...state, posts: action.payload };
    case REMOVE_POST:
      return {
        ...state,
        posts: state.posts.filter((post) => post.id !== action.payload),
      };
    case SET_PAGE:
      return { ...state, currentPage: action.payload };
    default:
      return state;
  }
};

export default combineReducers({
  postState: postReducer,
});
