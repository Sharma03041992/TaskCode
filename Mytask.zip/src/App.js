import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { setPosts, removePost, setPage } from './redux/actions';
import './App.css';

const App = () => {
  const dispatch = useDispatch();
  const { posts, currentPage } = useSelector((state) => state.postState);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
      dispatch(setPosts(response.data));
      setLoading(false);
    };
    setTimeout(fetchPosts, 5000); // Simulate loading delay
  }, [dispatch]);

  const handleRemovePost = (postId) => {
    dispatch(removePost(postId));
  };

  const handlePageChange = (page) => {
    dispatch(setPage(page));
  };

  const postsPerPage = 6;
  const totalPages = Math.ceil(posts.length / postsPerPage);
  const startIndex = (currentPage - 1) * postsPerPage;
  const endIndex = startIndex + postsPerPage;
  const currentPosts = posts.slice(startIndex, endIndex);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="App">
      <div className="cards-container">
        {currentPosts.map((post) => (
          <div key={post.id} className="card">
            <h3>{post.title}</h3>
            <p>{post.body}</p>
            <button onClick={() => handleRemovePost(post.id)}>Remove</button>
          </div>
        ))}
      </div>
      <div className="pagination">
        <button
          disabled={currentPage === 1}
          onClick={() => handlePageChange(currentPage - 1)}
        >
          Previous
        </button>
        {[...Array(totalPages).keys()].map((number) => (
          <button
            key={number}
            className={currentPage === number + 1 ? 'active' : ''}
            onClick={() => handlePageChange(number + 1)}
          >
            {number + 1}
          </button>
        ))}
        <button
          disabled={currentPage === totalPages}
          onClick={() => handlePageChange(currentPage + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default App;
